# ChoreEditor

ChoreEditor is an Android-first video editing and motion-graphics project.

This repository preserves the supplied EffectCraft Rust source and adds a native Android starter in `android-app/`.

**Start here:** [`CHOREEDITOR-START-HERE.md`](CHOREEDITOR-START-HERE.md)

The Android starter can import media, preview video, manage a basic clip list, perform basic clip-list operations, and save project metadata. It is an early foundation—not yet a complete Alight Motion / After Effects replacement. The EffectCraft Rust engine is not yet connected to Android, and advanced compositing/export features remain future milestones.

To build a debug APK using GitHub Actions, upload this repository to GitHub, open Actions, and run **Build ChoreEditor Android APK**.

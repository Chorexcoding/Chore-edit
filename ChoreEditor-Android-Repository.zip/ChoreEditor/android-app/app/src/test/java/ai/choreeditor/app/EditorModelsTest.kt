package ai.choreeditor.app

import org.junit.Assert.assertEquals
import org.junit.Test

class EditorModelsTest {
    @Test fun visibleDurationNeverNegative() {
        val clip = EditorClip("1", "content://test", "test", 1000, 900, 100)
        assertEquals(0L, clip.visibleDurationMs)
    }

    @Test fun visibleDurationUsesTrimRange() {
        val clip = EditorClip("1", "content://test", "test", 5000, 1000, 4200)
        assertEquals(3200L, clip.visibleDurationMs)
    }
}

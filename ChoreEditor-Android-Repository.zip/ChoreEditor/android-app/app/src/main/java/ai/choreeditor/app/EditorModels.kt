package ai.choreeditor.app

import android.content.ContentResolver
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class EditorClip(
    val id: String,
    val uri: String,
    val title: String,
    val durationMs: Long,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = durationMs,
    val track: Int = 0
) {
    val visibleDurationMs: Long get() = (trimEndMs - trimStartMs).coerceAtLeast(0L)
}

data class EditorProject(
    val name: String = "Untitled Project",
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val clips: List<EditorClip> = emptyList()
)

object ProjectStore {
    private const val FILE_NAME = "choreeditor_project.json"

    fun save(context: Context, project: EditorProject) {
        val root = JSONObject()
            .put("schemaVersion", 1)
            .put("name", project.name)
            .put("width", project.width)
            .put("height", project.height)
            .put("fps", project.fps)
        val clips = JSONArray()
        project.clips.forEach { clip ->
            clips.put(JSONObject()
                .put("id", clip.id)
                .put("uri", clip.uri)
                .put("title", clip.title)
                .put("durationMs", clip.durationMs)
                .put("trimStartMs", clip.trimStartMs)
                .put("trimEndMs", clip.trimEndMs)
                .put("track", clip.track))
        }
        root.put("clips", clips)
        File(context.filesDir, FILE_NAME).writeText(root.toString(2))
    }

    fun load(context: Context): EditorProject? {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return null
        return runCatching {
            val root = JSONObject(file.readText())
            val clipsJson = root.optJSONArray("clips") ?: JSONArray()
            val clips = buildList {
                for (i in 0 until clipsJson.length()) {
                    val item = clipsJson.getJSONObject(i)
                    val duration = item.optLong("durationMs", 0L)
                    add(EditorClip(
                        id = item.optString("id"),
                        uri = item.optString("uri"),
                        title = item.optString("title", "Media"),
                        durationMs = duration,
                        trimStartMs = item.optLong("trimStartMs", 0L),
                        trimEndMs = item.optLong("trimEndMs", duration),
                        track = item.optInt("track", 0)
                    ))
                }
            }
            EditorProject(
                name = root.optString("name", "Untitled Project"),
                width = root.optInt("width", 1080),
                height = root.optInt("height", 1920),
                fps = root.optInt("fps", 30),
                clips = clips
            )
        }.getOrNull()
    }
}

fun readMediaDurationMs(context: Context, uri: Uri): Long {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, uri)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } catch (_: Exception) {
        0L
    } finally {
        runCatching { retriever.release() }
    }
}

fun formatTime(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val minutes = safe / 60_000
    val seconds = (safe / 1_000) % 60
    val millis = (safe % 1_000) / 10
    return "%02d:%02d.%02d".format(minutes, seconds, millis)
}

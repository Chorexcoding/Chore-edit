package ai.choreeditor.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.UUID

private val Bg = Color(0xFF0D0D13)
private val Panel = Color(0xFF171721)
private val Panel2 = Color(0xFF222231)
private val Accent = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9292A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChoreEditorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChoreEditorApp() {
    val context = LocalContext.current
    var project by remember { mutableStateOf(ProjectStore.load(context) ?: EditorProject()) }
    var selectedClipId by remember { mutableStateOf<String?>(null) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Import media to start editing") }
    var showExportInfo by remember { mutableStateOf(false) }

    val selectedClip = project.clips.firstOrNull { it.id == selectedClipId }
    val player = remember { ExoPlayer.Builder(context).build() }

    DisposableEffect(Unit) { onDispose { player.release() } }

    val importMedia = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val newClips = uris.map { uri ->
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                val duration = readMediaDurationMs(context, uri)
                EditorClip(
                    id = UUID.randomUUID().toString(),
                    uri = uri.toString(),
                    title = queryDisplayName(context.contentResolver, uri),
                    durationMs = duration,
                    trimEndMs = duration
                )
            }
            val updatedProject = project.copy(clips = project.clips + newClips)
            project = updatedProject
            selectedClipId = newClips.firstOrNull()?.id
            message = "${newClips.size} media item(s) imported"
            ProjectStore.save(context, updatedProject)
        }
    }

    LaunchedEffect(selectedClip?.uri) {
        val clip = selectedClip
        if (clip != null) {
            runCatching {
                player.setMediaItem(MediaItem.fromUri(Uri.parse(clip.uri)))
                player.prepare()
                player.pause()
                isPlaying = false
            }.onFailure { message = "Could not load preview: ${it.message}" }
        } else {
            player.stop()
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ChoreEditor", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text(project.name, color = Muted, fontSize = 11.sp)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { message = "ChoreEditor project workspace" }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            ProjectStore.save(context, project)
                            message = "Project saved on this device"
                        }) { Icon(Icons.Default.Save, contentDescription = "Save project") }
                        IconButton(onClick = { showExportInfo = true }) {
                            Icon(Icons.Default.FileDownload, contentDescription = "Export")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Bg,
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = true,
                        onClick = { message = "Edit workspace" },
                        icon = { Icon(Icons.Default.Tune, null) },
                        label = { Text("Edit") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = { message = "Effects panel will be expanded in the next engine phase" },
                        icon = { Icon(Icons.Default.Layers, null) },
                        label = { Text("Effects") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = { message = "Project settings" },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Settings") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .background(Bg)
            ) {
                PreviewPanel(
                    player = player,
                    selectedClip = selectedClip,
                    isPlaying = isPlaying,
                    onPlayPause = {
                        if (selectedClip != null) {
                            if (player.isPlaying) player.pause() else player.play()
                            isPlaying = player.isPlaying
                        }
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TIMELINE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(playheadMs), color = Accent, fontSize = 12.sp)
                    IconButton(onClick = { importMedia.launch(arrayOf("video/*", "audio/*", "image/*")) }) {
                        Icon(Icons.Default.Add, contentDescription = "Import media", tint = Accent)
                    }
                }

                TimelinePanel(
                    clips = project.clips,
                    selectedClipId = selectedClipId,
                    onSelect = { selectedClipId = it },
                    onDelete = { id ->
                        val updatedProject = project.copy(clips = project.clips.filterNot { it.id == id })
                        project = updatedProject
                        if (selectedClipId == id) selectedClipId = updatedProject.clips.firstOrNull()?.id
                        ProjectStore.save(context, updatedProject)
                    },
                    onDuplicate = { clip ->
                        val duplicate = clip.copy(id = UUID.randomUUID().toString(), title = "${clip.title} copy")
                        val updatedProject = project.copy(clips = project.clips + duplicate)
                        project = updatedProject
                        selectedClipId = duplicate.id
                        ProjectStore.save(context, updatedProject)
                    },
                    onSplit = { clip ->
                        val splitAt = clip.trimStartMs + (clip.visibleDurationMs / 2)
                        if (splitAt > clip.trimStartMs && splitAt < clip.trimEndMs) {
                            val left = clip.copy(id = UUID.randomUUID().toString(), trimEndMs = splitAt)
                            val right = clip.copy(
                                id = UUID.randomUUID().toString(),
                                trimStartMs = splitAt,
                                title = "${clip.title} (2)"
                            )
                            val updatedProject = project.copy(
                                clips = project.clips.flatMap { if (it.id == clip.id) listOf(left, right) else listOf(it) }
                            )
                            project = updatedProject
                            selectedClipId = right.id
                            ProjectStore.save(context, updatedProject)
                            message = "Clip split at midpoint (basic timeline operation)"
                        }
                    }
                )

                selectedClip?.let { clip ->
                    ClipProperties(
                        clip = clip,
                        onRemove = {
                            val updatedProject = project.copy(clips = project.clips.filterNot { it.id == clip.id })
                            project = updatedProject
                            selectedClipId = null
                            ProjectStore.save(context, updatedProject)
                        }
                    )
                } ?: EmptyState(onImport = {
                    importMedia.launch(arrayOf("video/*", "audio/*", "image/*"))
                })

                Spacer(Modifier.weight(1f))
                Text(
                    message,
                    color = Muted,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }

    if (showExportInfo) {
        AlertDialog(
            onDismissRequest = { showExportInfo = false },
            title = { Text("Export engine") },
            text = {
                Text(
                    "The Android starter currently imports media, previews clips, edits a basic timeline and saves project data. " +
                    "A production multi-layer renderer and MP4 export pipeline are not connected yet. " +
                    "Next development phase: integrate and adapt EffectCraft's Rust render/media crates for Android."
                )
            },
            confirmButton = {
                TextButton(onClick = { showExportInfo = false }) { Text("Understood") }
            },
            containerColor = Panel
        )
    }
}

@Composable
private fun PreviewPanel(
    player: ExoPlayer,
    selectedClip: EditorClip?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Box(
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp)).background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (selectedClip != null) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            this.player = player
                            useController = true
                            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                        }
                    },
                    update = { it.player = player },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FolderOpen, null, tint = Muted, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Preview Monitor", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Import a video to preview it here", color = Muted, fontSize = 11.sp)
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                selectedClip?.title ?: "No clip selected",
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            FilledIconButton(
                onClick = onPlayPause,
                enabled = selectedClip != null,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent)
            ) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
        }
    }
}

@Composable
private fun TimelinePanel(
    clips: List<EditorClip>,
    selectedClipId: String?,
    onSelect: (String) -> Unit,
    onDelete: (String) -> Unit,
    onDuplicate: (EditorClip) -> Unit,
    onSplit: (EditorClip) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 250.dp)
            .padding(horizontal = 12.dp).clip(RoundedCornerShape(14.dp)).background(Panel)
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TRACK 01  ·  MEDIA", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${clips.size} clips", color = Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(10.dp))
        if (clips.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("Your timeline is empty", color = Muted, fontSize = 12.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(clips, key = { it.id }) { clip ->
                    val selected = clip.id == selectedClipId
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (selected) Color(0xFF383052) else Panel2)
                            .clickable { onSelect(clip.id) }
                            .padding(horizontal = 9.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(4.dp, 34.dp).clip(CircleShape)
                                .background(if (selected) Accent else Color(0xFF5C5C70))
                        )
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(clip.title, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${formatTime(clip.trimStartMs)} – ${formatTime(clip.trimEndMs)}",
                                color = Muted,
                                fontSize = 9.sp
                            )
                        }
                        IconButton(onClick = { onSplit(clip) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.ContentCut, "Split clip", tint = Muted, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { onDuplicate(clip) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Add, "Duplicate clip", tint = Muted, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { onDelete(clip.id) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Delete, "Delete clip", tint = Color(0xFFFF7777), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClipProperties(clip: EditorClip, onRemove: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(12.dp)).background(Panel).padding(12.dp)
    ) {
        Text("SELECTED CLIP", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(clip.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Duration", color = Muted, fontSize = 11.sp)
            Text(formatTime(clip.visibleDurationMs), color = Color.White, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Source duration", color = Muted, fontSize = 11.sp)
            Text(formatTime(clip.durationMs), color = Color.White, fontSize = 11.sp)
        }
        TextButton(onClick = onRemove, contentPadding = PaddingValues(0.dp)) {
            Text("Remove clip", color = Color(0xFFFF7777), fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmptyState(onImport: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Start creating", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text("Add footage, audio or images to your project.", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(10.dp))
        Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(6.dp))
            Text("Import Media")
        }
    }
}

private fun queryDisplayName(resolver: android.content.ContentResolver, uri: Uri): String {
    val projection = arrayOf(android.provider.OpenableColumns.DISPLAY_NAME)
    return runCatching {
        resolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                cursor.getString(cursor.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME))
            } else null
        }
    }.getOrNull() ?: "Media"
}

# ChoreEditor Android

Native Android starter for the ChoreEditor project. See [`../CHOREEDITOR-START-HERE.md`](../CHOREEDITOR-START-HERE.md) for setup, GitHub Actions APK build instructions, current limitations and roadmap.

Package: `ai.choreeditor.app`
Minimum Android: API 26 (Android 8.0)
Target SDK: 35

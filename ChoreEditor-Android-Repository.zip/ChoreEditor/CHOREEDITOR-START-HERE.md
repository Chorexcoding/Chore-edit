# ChoreEditor — Android starter repository

This repository contains:
- The supplied EffectCraft source tree (preserved under the repository root).
- A separate native Android application in `android-app/`.
- A GitHub Actions workflow that builds a debug APK.

## What works in this starter

The Android app currently includes:
- Dark ChoreEditor workspace UI.
- Import of video, audio and image files using Android's document picker.
- Real video preview using AndroidX Media3 ExoPlayer.
- Basic media clip list/timeline.
- Select, duplicate, remove and midpoint split operations on clips.
- Project JSON save/load in app-private storage.
- GitHub Actions debug APK build and unit test workflow.

## What is NOT implemented yet

This is an initial Android shell, not a finished Alight Motion / After Effects replacement.
In particular:
- The EffectCraft Rust crates are not yet compiled for Android or connected through JNI.
- The current timeline is a basic clip list, not a frame-accurate multitrack compositor.
- Split currently creates two trim-range entries at the clip midpoint; it does not render a new media file.
- Keyframes, Graph Editor, masks, effects, tracking, 3D and expressions are not yet wired into this Android UI.
- There is no MP4 export pipeline in this starter. The Export button explicitly explains this rather than pretending to export.
- Image/audio preview and advanced codec handling need additional implementation.

## Build the APK using GitHub (phone-friendly route)

1. Create a GitHub account and a new empty repository, for example `ChoreEditor`.
2. Download and extract this ZIP on your device or computer.
3. Upload the **contents** of this folder to the root of your GitHub repository. Make sure `.github/workflows/choreeditor-android.yml` is included.
4. Open your repository on GitHub.
5. Go to **Actions**.
6. Select **Build ChoreEditor Android APK**.
7. Tap **Run workflow** (or push a commit under `android-app/` to trigger it).
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run and download the `ChoreEditor-debug-apk` artifact.
10. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Allow installation from your browser/files app if Android asks.

If the workflow fails, open the failed step, copy the error log, and give it to your coding AI. Do not guess at fixes.

## Local build (optional)

Requirements: JDK 17, Android SDK platform 35, Gradle 8.9.

```bash
gradle -p android-app :app:assembleDebug
gradle -p android-app :app:testDebugUnitTest
```

APK output:
`android-app/app/build/outputs/apk/debug/app-debug.apk`

## Next engineering milestones

1. Inspect and document the Rust crates needed for project, timeline, render, GPU, media and export.
2. Create an Android-compatible Rust build using the Android NDK and Cargo targets.
3. Expose a narrow, versioned JNI interface (prefer UniFFI or carefully scoped JNI).
4. Connect project serialization and engine commands to the Android UI.
5. Implement a real composition timeline with timebase/frame-accurate operations.
6. Implement GPU preview and render graph.
7. Add keyframes and Graph Editor.
8. Add effects, masks, blending and text.
9. Add audio mixing, render queue and MP4 export.
10. Add device-specific performance tests and recovery.

## Licensing

The supplied EffectCraft repository includes MIT and Apache-2.0 license files and attribution material. Preserve those notices. Audit the licenses of all transitive dependencies and any added libraries before distributing ChoreEditor. Do not use proprietary Adobe/Alight Motion assets, branding, or source code.
